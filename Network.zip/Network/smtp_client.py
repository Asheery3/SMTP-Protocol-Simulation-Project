import socket
import ssl
import base64
from datetime import datetime

def log_email(from_email, to_email, subject):
    with open("email_log.txt", "a") as log:
        log.write(f"[{datetime.now()}] From: {from_email}, To: {to_email}, Subject: {subject}\n")

def send_email(smtp_server, port, username, password, from_email, to_email, subject, message):
    try:
        client_socket = socket.create_connection((smtp_server, port))
        client_socket.recv(1024)

        client_socket.send(b"EHLO localhost\r\n")
        client_socket.recv(1024)

        client_socket.send(b"STARTTLS\r\n")
        client_socket.recv(1024)

        secure_socket = ssl.wrap_socket(client_socket)
        secure_socket.send(b"EHLO localhost\r\n")
        secure_socket.recv(1024)

        secure_socket.send(b"AUTH LOGIN\r\n")
        secure_socket.recv(1024)
        secure_socket.send(base64.b64encode(username.encode()) + b"\r\n")
        secure_socket.recv(1024)
        secure_socket.send(base64.b64encode(password.encode()) + b"\r\n")
        secure_socket.recv(1024)

        secure_socket.send(f"MAIL FROM:<{from_email}>\r\n".encode())
        secure_socket.recv(1024)
        secure_socket.send(f"RCPT TO:<{to_email}>\r\n".encode())
        secure_socket.recv(1024)
        secure_socket.send(b"DATA\r\n")
        secure_socket.recv(1024)

        email_content = f"From: {from_email}\r\nTo: {to_email}\r\nSubject: {subject}\r\n\r\n{message}\r\n.\r\n"
        secure_socket.send(email_content.encode())
        secure_socket.recv(1024)

        secure_socket.send(b"QUIT\r\n")
        secure_socket.recv(1024)

        log_email(from_email, to_email, subject)

        return True, "Email sent successfully!"

    except Exception as e:
        return False, f"Error: {str(e)}"


def test_connection(smtp_server, port):
    try:
        test_socket = socket.create_connection((smtp_server, port))
        test_socket.close()
        return True
    except Exception:
        return False
