# SMTP Email Sender (Manual) - Streamlit App

This project is a simple manual SMTP email sender built with Python and Streamlit.

## Features

- Manual SMTP email sending (using socket & SSL)
- Connection testing to SMTP server
- Login system (simple + secure)
- Log file records all sent messages with timestamps
- User-friendly interface

## Files

- `main.py`: Streamlit app interface and login
- `smtp_client.py`: Core email sending and logging
- `email_log.txt`: Generated log file after sending
- `requirements.txt`: Python dependencies

## How to Use

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Run the app:

```bash
streamlit run main.py
```

3. Log in with:

- Username: `admin`
- Password: `admin123`

## Notes

- Your email will be recorded in `email_log.txt` with subject and time.
- For testing use Mailtrap or Gmail SMTP (with app password).

---

Created by: **Ahd**
