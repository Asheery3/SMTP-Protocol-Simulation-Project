import streamlit as st
from smtp_client import send_email, test_connection
import hashlib

def login(username, password):
    correct_username = "admin"
    correct_password = hashlib.sha256("admin123".encode()).hexdigest()
    return username == correct_username and hashlib.sha256(password.encode()).hexdigest() == correct_password

st.set_page_config(page_title="SMTP Sender", page_icon="✉️")

if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False

if not st.session_state["logged_in"]:
    st.markdown("## Welcome to the Email Sender App")
    st.markdown("Please log in to access the system.")

    with st.form("login_form"):
        username = st.text_input("Username", placeholder="Enter your username")
        password = st.text_input("Password", type="password", placeholder="Enter your password")
        if st.form_submit_button("Log in"):
            if login(username, password):
                st.session_state["logged_in"] = True
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid username or password.")
else:
    st.title("SMTP Manual Email Sender")

    smtp_server = st.text_input("SMTP Server", value="smtp.mailtrap.io")
    port = st.number_input("Port", value=587)
    username = st.text_input("SMTP Username")
    password = st.text_input("SMTP Password", type="password")
    from_email = st.text_input("From Email")
    to_email = st.text_input("To Email")
    subject = st.text_input("Subject")
    message = st.text_area("Message")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("Send Email"):
            with st.spinner("Sending..."):
                success, response = send_email(
                    smtp_server, port, username, password, from_email, to_email, subject, message
                )
                if success:
                    st.success(response)
                else:
                    st.error(response)

    with col2:
        if st.button("Test Connection"):
            if test_connection(smtp_server, port):
                st.success("Connection successful.")
            else:
                st.error("Connection failed.")

    if st.button("Logout"):
        st.session_state["logged_in"] = False
        st.rerun()
