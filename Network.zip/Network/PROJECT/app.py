from flask import Flask, render_template, request
import socket
import ssl
import base64
import socket as sys_socket

app = Flask(__name__)

def send_and_recv(sock, command, rfc_note=""):
    """Send command to SMTP server and receive response"""
    if rfc_note:
        print(f"\n📘 RFC 5321 - {rfc_note}")
    print(f">> Client: {command}")
    sock.send((command + "\r\n").encode())
    recv = sock.recv(1024).decode()
    print(f"<< Server: {recv.strip()}")
    return recv

def send_email_socket(sender, password, recipient, subject, body):
    try:
        server = "smtp.gmail.com"
        port = 587
        protocol = "SMTP"
        ip = sys_socket.gethostbyname(server)

        print("=" * 60)
        print("📡 Starting Email Transmission via Raw Socket")
        print(f"🔌 Server: {server}")
        print(f"🌍 IP Address: {ip}")
        print(f"📨 Protocol: {protocol}")
        print(f"🛠️ Port: {port}")
        print("=" * 60)

        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.settimeout(10)
        client_socket.connect((server, port))

        response = client_socket.recv(1024).decode()
        print(f"👋 Server Hello: {response.strip()}")


        send_and_recv(client_socket, "HELO localhost", "4.1.1.1 - HELO command")

        
        send_and_recv(client_socket, "STARTTLS", "RFC 3207 - STARTTLS for secure SMTP")

      
        context = ssl.create_default_context()
        client_socket = context.wrap_socket(client_socket, server_hostname=server)
        print("🔒 TLS Handshake completed and connection is now secure.")

        
        send_and_recv(client_socket, "EHLO localhost", "4.1.1.1 - EHLO for extended SMTP")

        send_and_recv(client_socket, "AUTH LOGIN", "RFC 4954 - AUTH LOGIN")

       
        send_and_recv(client_socket, base64.b64encode(sender.encode()).decode(), "Base64 Encoded Username")
        send_and_recv(client_socket, base64.b64encode(password.encode()).decode(), "Base64 Encoded Password")

    
        send_and_recv(client_socket, f"MAIL FROM:<{sender}>", "4.1.1.2 - MAIL FROM")

   
        send_and_recv(client_socket, f"RCPT TO:<{recipient}>", "4.1.1.3 - RCPT TO")

       
        send_and_recv(client_socket, "DATA", "4.1.1.4 - DATA command, start email content")

        print("=" * 60)
        print("✉️ Preparing email message:")
        print(f"From: {sender}")
        print(f"To: {recipient}")
        print(f"Subject: {subject}")
        print("Message Body:")
        print(body)
        print("=" * 60)

        message = f"From: {sender}\r\nTo: {recipient}\r\nSubject: {subject}\r\n\r\n{body}"
        client_socket.send((message + "\r\n.\r\n").encode())

        final_response = client_socket.recv(1024).decode()
        print(f"<< Server: {final_response.strip()}")


        send_and_recv(client_socket, "QUIT", "4.1.1.10 - QUIT command to end session")

        client_socket.close()
        print("✅ Email sent successfully.")
        print("=" * 60)
        return "✅ Email sent successfully."

    except Exception as e:
        print("❌ Error occurred during email transmission.")
        print(f"Error Details: {str(e)}")
        print("=" * 60)
        return f"❌ Error: {str(e)}"

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    if request.method == "POST":
        sender = request.form.get("sender", "").strip()
        password = request.form.get("password", "").strip()
        recipient = request.form.get("recipient", "").strip()
        subject = request.form.get("subject", "").strip()
        body = request.form.get("body", "").strip()

        # تحقق من أن الحقول الأساسية ليست فارغة
        if not sender or not password or not recipient or not subject or not body:
            result = "⚠️ Please fill in all the fields."
        else:
            result = send_email_socket(sender, password, recipient, subject, body)
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
